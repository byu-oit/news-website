<?php

namespace Drupal\byu_migrate_news\Controller;

use Drupal\Core\Controller\ControllerBase;
use \Drupal\node\Entity\Node;
use \Drupal\file\Entity\File;
use Drupal\taxonomy\Entity\Term;

/**
 * Class MigrateImagesController.
 */
class MigrateNewsController extends ControllerBase {

  /**
   * Migrateimages.
   *
   * @return string
   *   Return Hello string.
   */
    public function migrateimages() {
        $output = "";
        /**
         * Clean out old media
         */
        //   $images_result = db_query("select fid from file_managed");
        //   foreach ($images_result as $imagerow) {
        //       $fid = $imagerow->fid;
        //       file_delete($fid);
        //   }
        $lastfid = 0;
        $images_result = db_query("select * from drupal7_news.file_managed order by fid");
        foreach ($images_result as $imagerow) {
            $fid = $imagerow->fid;
            $values = \Drupal::entityQuery('file')->condition('fid', $fid)->execute();
            $node_exists = !empty($values);
            if (!$node_exists) {
                $filename = $imagerow->filename;
                $uri = $imagerow->uri;
                if ($uri > "") {

                } else {
                    $uri = " ";
                }
                $filemime = $imagerow->filemime;
                $filesize = $imagerow->filesize;
                $filetype = $imagerow->type;

                $image = File::create();
                $image->fid = $fid;
                $image->setFileUri($uri);
                $image->setMimeType($filemime);
                $image->setFileName($filename);
                $image->filesize = $filesize;
                $image->type = $filetype;
                $image->setPermanent();

                $photocredit = db_query("select field_credit_value from drupal7_news.field_data_field_credit where entity_id = $fid")->fetchField();

                if ($photocredit > "") {
                    $query = \Drupal::entityQuery('taxonomy_term');
                    $query->condition('vid', "photographers");
                    $query->condition('name', $photocredit);
                    $tids = $query->execute();

                    if (empty($tids)) {
                        $new_term = Term::create([
                            'name' => $photocredit,
                            'vid' => 'photographers',
                        ])->save();
                        $fieldtid = $new_term->id();
                    } else {

                        $fieldtid = implode($tids);

                    }



                }


                $image->save();
                $image->field_photo_credit[] = ['target_id' => $fieldtid];
                $image->save();
                $lastfid = $fid;
            }

        }
        if ($lastfid == 0) {
            $output .= "No images loaded.";
        } else {
            $output .= "Images Loaded...Last fid: " . $lastfid;
        }
        return [
            '#type' => 'markup',
            '#markup' => $this->t($output)
        ];
    }

  /**
   * Migratestories.
   *
   * @return string
   *   Return Hello string.
   */
    public function migratestories() {
        $query = "select nid, title, created, status from drupal7_news.node where type = 'story' order by nid";
        $sql_result = db_query($query);
        $lastnid = 0;
        foreach ($sql_result as $row) {
            $nid = $row->nid;
            $values = \Drupal::entityQuery('node')->condition('nid', $nid)->execute();
            $node_exists = !empty($values);
            if (! $node_exists) {
                $status = $row->status;
                if ($status == 1) {
                    $moderationstate = 'published';
                } else {
                    $moderationstate = 'draft';
                }

                $created = $row->created;
                $published = date("Y-m-d", $created);
                $title = $row->title;
                if ($title > ""){

                } else {
                    $title = "  ";
                }
                $bodytext = db_query("select body_value from drupal7_news.field_data_body where entity_id = $nid")->fetchField();
                $bodyformat = db_query("select body_format from drupal7_news.field_data_body where entity_id = $nid")->fetchField();
                $bodysummary = db_query("select body_summary from drupal7_news.field_data_body where entity_id = $nid")->fetchField();
                $contactphone = db_query("select field_contact_phone_value from drupal7_news.field_data_field_contact_phone where entity_id = $nid")->fetchField();
                $contactemail = db_query("select field_contact_email_email from drupal7_news.field_data_field_contact_email where entity_id = $nid")->fetchField();
                $fullname = db_query("select field_first_name_value from drupal7_news.field_data_field_first_name where entity_id = $nid")->fetchField();
                $publicize = db_query("select field_publicize_value from drupal7_news.field_data_field_publicize where entity_id = $nid")->fetchField();
                $showonfront = 'false';
                if ($publicize == 'publicize') {
                    $showonfront = 'true';
                }
                $subhead = db_query("select field_headline_value from drupal7_news.field_data_field_headline where entity_id = $nid")->fetchField();
                $highlights = db_query("select field_highlights_value from drupal7_news.field_data_field_highlights where entity_id = $nid")->fetchField();
                $mediacontacttype = db_query("select field_media_contact_type_value from drupal7_news.field_data_field_media_contact_type where entity_id = $nid")->fetchField();
                $writertype = db_query("select field_writer_type_value from drupal7_news.field_data_field_writer_type where entity_id = $nid")->fetchField();
                $authortid = db_query("select field_author_target_id from drupal7_news.field_data_field_author where entity_id = $nid")->fetchField();
                $writername = db_query("select field_writer_name_value from drupal7_news.field_data_field_writer_name where entity_id = $nid")->fetchField();
                if ($writername > "") {
                    if (strpos($writername, ';' == false)) {
                        $writeruid = db_query("select uid from users_field_data where name='$writername'")->fetchField();
                    } else {
                        $writeruid = 0;
                    }
                } else {
                    $writeruid = 0;
                }
                $categorytid = db_query("select field_newsletter_category_tid from drupal7_news.field_data_field_newsletter_category where entity_id = $nid")->fetchField();
                $mediacontacttid = db_query("select field_media_contact_target_id from drupal7_news.field_data_field_media_contact where entity_id = $nid")->fetchField();
                if ($mediacontacttid > "") {
                    $mediacontactname = db_query("select title from drupal7_news.node where nid = $mediacontacttid")->fetchField();
                }
                $mediauid = db_query("select uid from users_field_data where name = '$mediacontactname'")->fetchField();

                $node = Node::create([
                    'type' => 'story',
                    'langcode' => 'en',
                    'created' => $published,
                    'nid' => $nid,
                    'title' => $title,
                    'moderation_state' => $moderationstate,
                    'body' => [
                        'value' => $bodytext,
                        'format' => $bodyformat,
                    ],
                    'field_summary' => [
                        'value' => $bodysummary,
                        'format' => 'full_html',
                    ],
                    'field_show_on_front' => $showonfront,
                    'field_publish_date' => $published,
                    'field_category' => [
                        ['target_id' => $categorytid]
                    ],

                ]);

                if ($contactemail > "") {
                    $node->field_contact_email = $contactemail;
                }
                if ($contactphone > "") {
                    $node->field_contact_phone = $contactphone;
                }
                if ($fullname > "") {
                    $node->field_full_name = $fullname;
                }
                if ($subhead > "") {
                    $node->field_subheading = $subhead;
                }
                if ($highlights > "") {
                    $node->field_story_highlights = $highlights;
                }
                if ($mediacontacttype > "") {
                    $node->field_media_contact_type = $mediacontacttype;
                }
                if ($writername > "") {
                    $node->field_writer_name = $writername;
                }
                if ($writertype > "") {
                    $node->field_writer_type = $writertype;
                }

                if ($mediauid > 0) {
                    $node->field_media_contact_byline_perso = ['target_id' => $mediauid];
                }

                $links_result = db_query("select field_link_url, field_link_title from drupal7_news.field_data_field_link where entity_id = $nid");
                foreach ($links_result as $linkrow) {
                    $node->field_media_placement[] = ['uri' => $linkrow->field_link_url, 'title' => $linkrow->field_link_title];
                }
                $related_result = db_query("select field_related_target_id from drupal7_news.field_data_field_related where entity_id = $nid");
                foreach ($related_result as $relatedrow) {
                    $node->field_related_stories[] = $relatedrow->field_related_target_id;
                }
                $tags_result = db_query("select field_tags_tid from drupal7_news.field_data_field_tags where entity_id = $nid");
                foreach ($tags_result as $tagsrow) {
                    $tagid = $tagsrow->field_tags_tid;
                    $tagname = db_query("select name from drupal7_news.taxonomy_term_data where tid = $tagid")->fetchField();
                    if ($tagname > "") {
                        $query = \Drupal::entityQuery('taxonomy_term');
                        $query->condition('vid', "tags");
                        $query->condition('name', $tagname);
                        $tids = $query->execute();
                        if (empty($tids)) {
                            $new_term = Term::create([
                                'name' => $tagname,
                                'vid' => 'tags',
                            ])->save();

                            $fieldtid = $new_term->id();
                        } else {
                            $fieldtid = implode($tids);
                        }
                        $node->field_tags[] = $fieldtid;
                    }
                }
                if ($writeruid > 0) {
                    $node->field_writer_person_ = $writeruid;
                }

                $images_result = db_query("select field_photos_fid from drupal7_news.field_data_field_photos where entity_id = $nid");
                foreach ($images_result as $imagerow) {
                    $imagefid = $imagerow->field_photos_fid;
                    $node->field_image[] = ['target_id' => $imagefid];
                }

                $thumbnailtid = db_query("select field_feature_image_fid from drupal7_news.field_data_field_feature_image where entity_id = $nid")->fetchField();
                if ($thumbnailtid > 0) {
                    $node->field_thumbnail[] = ['target_id' => $thumbnailtid];
                }

                $node->save();
                $lastnid = $nid;
            }

        }
        if ($lastnid == 0) {
            $output = "No Stories Loaded.";
        } else {
            $output = "Stories loaded...last nid: " . $nid;
        }
        return [
            '#type' => 'markup',
            '#markup' => $this->t($output)
        ];
    }
    public function deletenodes() {
        $nodes = \Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(array('type' => 'story'));
        foreach ($nodes as $node) {
            $node->delete();
        }
        return [
            '#type' => 'markup',
            '#markup' => $this->t("Nodes Deleted!")
        ];
    }
    public function deleteimages() {
        $images_result = db_query("select fid from file_managed");
        foreach ($images_result as $imagerow) {
            $fid = $imagerow->fid;

            file_delete($fid);
        }
        return [
            '#type' => 'markup',
            '#markup' => $this->t("Images Deleted!")
        ];
    }

}
